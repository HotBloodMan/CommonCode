package startimes.com.aidlclient2;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import startimes.com.aidlservice.ICat;

public class AidlClient extends Activity {

    private ICat catService;
    private Button get;
    EditText color,weight;
    private ServiceConnection conn=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            //获取远程Service的onBind方法返回的对象代理
            catService=ICat.Stub.asInterface(iBinder);

            get.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        //获取，并显示远程Service的状态
                        color.setText(catService.getColor());
                        Toast.makeText(AidlClient.this,catService.getColor()+"",Toast.LENGTH_LONG).show();
                        weight.setText(catService.getWeight()+"");
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }
        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            catService=null;
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aidl_client);
        get= (Button) findViewById(R.id.get);
        color= (EditText) findViewById(R.id.color);
        weight= (EditText) findViewById(R.id.weight);
        //创建所需绑定服务的Intent
        Intent intent = new Intent();
        intent.setAction("startimes.com.aidlservice.Aidl_Service");
        //绑定远程服务
        bindService(intent,conn, Service.BIND_AUTO_CREATE);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //解除绑定
        this.unbindService(conn);
    }
}
